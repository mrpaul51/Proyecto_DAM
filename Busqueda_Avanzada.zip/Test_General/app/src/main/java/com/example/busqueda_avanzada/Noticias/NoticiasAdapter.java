package com.example.busqueda_avanzada.Noticias;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.busqueda_avanzada.R;
import com.squareup.picasso.Picasso;

import java.lang.ref.Reference;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;




public class NoticiasAdapter extends ArrayAdapter<Noticia> {

    Activity actividad;
    int idLayout;
    List<Noticia> listaNoticias;

    //Constructor
    public NoticiasAdapter(@NonNull Context context, int resource, @NonNull List<Noticia> noticias) {
        super(context, resource, noticias);

            actividad = (Activity) context;
            idLayout = resource;
            listaNoticias = noticias;
    }

    static class Referencias{
        //Aqui van los elementos que componen la noticia en la interfaz (imageView, textView...)
        ImageView imagenNoticia;
        TextView tituloNoticia, fechaNoticia, webNoticia;


    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View layout_Personalizado;
        LayoutInflater inflador;
        Referencias ref;

        if (convertView == null ) {
            inflador = actividad.getLayoutInflater();
            layout_Personalizado = inflador.inflate(idLayout, null);

            ImageView imv_imagen = layout_Personalizado.findViewById(R.id.imv_imagenNoticia);
            TextView tv_titulo = layout_Personalizado.findViewById(R.id.tv_tituloNoticia);
            TextView tv_fecha = layout_Personalizado.findViewById(R.id.tv_fechaNoticia);
            TextView tv_web = layout_Personalizado.findViewById(R.id.tv_webNoticia);

            ref = new Referencias();

            ref.tituloNoticia = tv_titulo;
            ref.fechaNoticia = tv_fecha;
            ref.imagenNoticia = imv_imagen;
            ref.webNoticia = tv_web;


            layout_Personalizado.setTag(ref);
        }

        else {
            layout_Personalizado = convertView;
            ref = (Referencias) layout_Personalizado.getTag();
        }

        Noticia noticia = listaNoticias.get(position);

        ref.fechaNoticia.setText(noticia.getFechaPublicacion().toString());
        ref.webNoticia.setText(noticia.getEnlace().toString());
        Picasso.get().load(noticia.getImagen().toString()).into(ref.imagenNoticia);
        ref.tituloNoticia.setText((noticia.getTitulo().toString()));

        return layout_Personalizado;
    }
}
