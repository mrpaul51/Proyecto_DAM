package com.example.busqueda_avanzada.GoogleTrends;

import android.renderscript.Sampler;

import java.util.List;
/*
public class Trends {

    private String id;
    private String status;
    private String jsonEndpoint;
    private String createdAt;
    private String processedAt;
    private String googleTrendsUrl;
   private List<TimelineData> timelineData;

    public class TimelineData {
        private String date;
        private String timestamp;
        private List<Value> values;

    }


    public class Value {
        private String query;
        private String value;
        private int extractedValue;


    }


}
        */