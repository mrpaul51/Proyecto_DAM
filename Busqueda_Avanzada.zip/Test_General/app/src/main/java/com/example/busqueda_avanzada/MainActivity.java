package com.example.busqueda_avanzada;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import com.example.busqueda_avanzada.Noticias.Fragmento_Noticias;
import com.example.busqueda_avanzada.Noticias.Noticia;
import com.example.busqueda_avanzada.Noticias.NoticiasSearchTask;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;


public class MainActivity extends AppCompatActivity {

    ImageButton imgAvanzado;
    LinearLayout layoutAvanzado;

    private TabLayout tabLayout;
    private ViewPager viewPager;
    ViewPageAdaptador vpAdaptador;

    ImageButton btn_buscar;

    ArrayList<Fragment> listaFragmentos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listaFragmentos = new ArrayList<>();


        imgAvanzado = findViewById(R.id.img_avanzado);
        layoutAvanzado = findViewById(R.id.layout_avanzado);

        //TAB LAYOUT
        viewPager = findViewById(R.id.view_pager);
        tabLayout = findViewById(R.id.tab_layout);

        //Esto es experimental
        Fragment fg1 = new Fragment();
        Fragment fg2 = new Fragment();
        Fragment fg3 = new Fragment();

        listaFragmentos.add(fg1);
        listaFragmentos.add(fg2);
        listaFragmentos.add(fg3);

        vpAdaptador = new ViewPageAdaptador(getSupportFragmentManager(), listaFragmentos);
        viewPager.setAdapter(vpAdaptador);


        tabLayout.setupWithViewPager(viewPager);



        //Se establecen las listas de elementos para los autocomplete textbox
        Set<String> listaPaises = new TreeSet<>();
        Locale esLocale = new Locale("es", "ES");

        for (Locale locale : Locale.getAvailableLocales()) {
            if (!TextUtils.isEmpty(locale.getDisplayCountry())) {
                listaPaises.add(locale.getDisplayCountry(esLocale));
            }
        }

        ArrayList<String> listaCategorias = new ArrayList<>(Arrays.asList(
                "Arte y entretenimiento",
                "Vehículos",
                "Belleza y Fitness",
                "Libros y Literatura",
                "Finanzas",
                "Cómics y dibujos animados",
                "Artesanía y aficiones",
                "Educación",
                "Electrónica y Gadgets",
                "Moda",
                "Comida",
                "Juegos",
                "Salud",
                "Hogar",
                "Jardín",
                "Humor",
                "Internet y telecomunicaciones",
                "Trabajos y carrera",
                "Gobierno y ley",
                "Estilo de vida",
                "Noticias",
                "Comunidades en línea",
                "Animales de compañía",
                "Bienes raíces",
                "Ciencia",
                "Compras",
                "Deportes",
                "Viajar",
                "Religión",
                "Historia",
                "Películas",
                "Clima"
        ));



        //Se crean y añaden los adapatadores al autocomplete
        ArrayAdapter<String> adaptadorPaises = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, listaPaises.toArray(new String[0]));
        AutoCompleteTextView paisAutocomplete = findViewById(R.id.acTV_paises);
        paisAutocomplete.setAdapter(adaptadorPaises);

        ArrayAdapter<String> adaptadorCategorias = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, listaCategorias.toArray(new String[0]));
        AutoCompleteTextView categoriasAutocomplete = findViewById(R.id.acTV_cateogria);
        categoriasAutocomplete.setAdapter(adaptadorCategorias);



        vpAdaptador = new ViewPageAdaptador(getSupportFragmentManager(), listaFragmentos);




        //DECLARACIÓN DE LAS TAREAS DE BÚSQUEDA

        NoticiasSearchTask noticiasSearchTask = new NoticiasSearchTask(new NoticiasSearchTask.NoticiasSearchListener() {
            @Override
            public void onNoticiasSearchCompleted(ArrayList<Noticia> listaNoticias) {

                listaFragmentos.add(new Fragmento_Noticias(listaNoticias));
                Log.d("LOG", "ListaNoticias tamaño:"+listaNoticias.size());


                vpAdaptador = new ViewPageAdaptador(getSupportFragmentManager(), listaFragmentos);
                Log.d("LOG", "ListaFragmentos tamaño:"+listaFragmentos.size());
                viewPager.setAdapter(vpAdaptador);


            }
            @Override
            public void onNoticiasSearchFailed(Exception e) {//error
                 }
        });



        imgAvanzado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (layoutAvanzado.getVisibility() == View.VISIBLE) {
                    layoutAvanzado.setVisibility(View.GONE);
                } else {
                    layoutAvanzado.setVisibility(View.VISIBLE);
                }

            }
        });




        btn_buscar = findViewById(R.id.img_buscar);

        btn_buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //se lanzan los threads
                //A este hilo hay que pasarle los parámetros de búsqueda
                noticiasSearchTask.execute("Vivienda", "es", "es");


            }
        });









        // Listener de TabLayout
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());

                Log.d("LOG", "Numero de tab:" + tab.getPosition());
                Log.d("LOG", "Lista size:" + listaFragmentos.size());
                Log.d("LOG", "vpAdaptador:" + vpAdaptador.getItem(tab.getPosition()));
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });




    }


}