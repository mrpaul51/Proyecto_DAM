package com.example.busqueda_avanzada.Noticias;

import org.json.JSONObject;

import java.net.URL;
import java.util.Date;

public class Noticia {


    private String titulo;
    private String descripcion;
    private String contenido;
    private URL enlace;
    private URL imagen;
    private Date fechaPublicacion;
    private Fuente fuente;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public URL getEnlace() {
        return enlace;
    }

    public void setEnlace(URL enlace) {
        this.enlace = enlace;
    }

    public URL getImagen() {
        return imagen;
    }

    public void setImagen(URL imagen) {
        this.imagen = imagen;
    }

    public Date getFechaPublicacion() {
        return fechaPublicacion;
    }
    //Sería conveniente hacer un método para obtener la fecha formateada

    public void setFechaPublicacion(Date fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public Fuente getFuente() {
        return fuente;
    }

    public void setFuente(Fuente fuente) {
        this.fuente = fuente;
    }

    public class Fuente {
        private String nombreFuente;
        private URL enlaceFuente;

        public String getNombreFuente() {
            return nombreFuente;
        }

        public void setNombreFuente(String nombreFuente) {
            this.nombreFuente = nombreFuente;
        }

        public URL getEnlaceFuente() {
            return enlaceFuente;
        }

        public void setEnlaceFuente(URL enlaceFuente) {
            this.enlaceFuente = enlaceFuente;
        }
    }



    // Al constructor se le pasa un objeto JSON y se extraen los atributos
    public Noticia(JSONObject jsonObject) throws Exception {
        titulo = jsonObject.getString("title");
        descripcion = jsonObject.getString("description");
        contenido = jsonObject.getString("content");
        enlace = new URL(jsonObject.getString("url"));
        imagen = new URL(jsonObject.getString("image"));
        fechaPublicacion = new Date(jsonObject.getString("publishedAt"));
        JSONObject sourceObject = jsonObject.getJSONObject("source");
        fuente = new Fuente();
        fuente.setNombreFuente(sourceObject.getString("name"));
        fuente.setEnlaceFuente(new URL(sourceObject.getString("url")));
    }


    //Ejemplo de noticia extraida de Gnews.
    /*
    {
  "totalArticles": 54904,
  "articles": [
    {
      "title": "Google's Pixel 7 and 7 Pro’s design gets revealed even more with fresh crisp renders",
      "description": "Now we have a complete image of what the next Google flagship phones will look like. All that's left now is to welcome them during their October announcement!",
      "content": "Google’s highly anticipated upcoming Pixel 7 series is just around the corner, scheduled to be announced on October 6, 2022, at 10 am EDT during the Made by Google event. Well, not that there is any lack of images showing the two new Google phones, b... [1419 chars]",
      "url": "https://www.phonearena.com/news/google-pixel-7-and-pro-design-revealed-even-more-fresh-renders_id142800",
      "image": "https://m-cdn.phonearena.com/images/article/142800-wide-two_1200/Googles-Pixel-7-and-7-Pros-design-gets-revealed-even-more-with-fresh-crisp-renders.jpg",
      "publishedAt": "2022-09-28T08:14:24Z",
      "source": {
        "name": "PhoneArena",
        "url": "https://www.phonearena.com"
      }
    }
  ]
}
     */


}
