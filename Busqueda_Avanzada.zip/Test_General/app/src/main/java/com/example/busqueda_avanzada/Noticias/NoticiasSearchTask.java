package com.example.busqueda_avanzada.Noticias;

import android.os.AsyncTask;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class NoticiasSearchTask extends AsyncTask<String, Void, Void> {

    private static final String TAG = "Tarea Noticias API";

    //https://gnews.io/docs/v4#search-endpoint

    private final NoticiasSearchListener mListener;

    public NoticiasSearchTask(NoticiasSearchListener listener) {
        mListener = listener;
    }
    private static final String NOTICIAS_API_KEY = "3cd9cc186313a226db60b5da0b0c14be";
    private static final String NOTICIAS_API_ENDPOINT = "https://gnews.io/api/v4/search?";


    @Override
    protected Void doInBackground(String... parametros) {

        ArrayList<Noticia> listaNoticias = new ArrayList<>();

        String clave = parametros[0];
        String pais = parametros[1];
        String idioma = parametros[2];

        try {
            String encodedClave = URLEncoder.encode(clave, "UTF-8");
            String encodedPais = URLEncoder.encode(pais, "UTF-8");
            String encodedIdioma = URLEncoder.encode(idioma, "UTF-8");
            //el idioma por defecto será el español, pero esto se configura en una activity de opciones

            String urlString = NOTICIAS_API_ENDPOINT
                    + "&q=" + encodedClave
                    + "&country=" + encodedPais
                    + "&lang=" + encodedIdioma
                    + "&apikey=" + NOTICIAS_API_KEY;

            URL url = new URL (urlString);
            HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
            conexion.setRequestMethod("GET");

            BufferedReader entrada = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
            StringBuilder respuestaBuilder = new StringBuilder();

            String linea;
            while ((linea = entrada.readLine()) != null) {
                respuestaBuilder.append(linea);
            }

            entrada.close();

            JsonObject respuestaJSON = JsonParser.parseString(respuestaBuilder.toString()).getAsJsonObject();
            Log.d(TAG, "response: " + respuestaJSON.toString());


            Gson gson = new Gson();
            JsonArray noticiasArray = respuestaJSON.getAsJsonArray("articles");

            for (int i = 0; i < noticiasArray.size(); i++) {
                JsonObject noticiaJSON = noticiasArray.get(i).getAsJsonObject();
                Noticia noticia = gson.fromJson(noticiaJSON.toString(), Noticia.class);
                listaNoticias.add(noticia);
            }
            mListener.onNoticiasSearchCompleted(listaNoticias);


        } catch (Exception e) {
        Log.e(TAG, "error", e);
        mListener.onNoticiasSearchFailed(e);
    }
        return null;
    }

    public interface NoticiasSearchListener {
        void onNoticiasSearchCompleted(ArrayList<Noticia> listaNoticias);
        void onNoticiasSearchFailed(Exception e);
    }




    /*

    Formato de las noticias recibidas

    {
        "totalArticles": 54904,
             "articles": [
                 {
                        "title": "Google's Pixel 7 and 7 Pro’s design gets revealed even more with fresh crisp renders",
                        "description": "Now we have a complete image of what the next Google flagship phones will look like. All that's left now is to welcome them during their October announcement!",
                        "content": "Google’s highly anticipated upcoming Pixel 7 series is just around the corner, scheduled to be announced on October 6, 2022, at 10 am EDT during the Made by Google event. Well, not that there is any lack of images showing the two new Google phones, b... [1419 chars]",
                        "url": "https://www.phonearena.com/news/google-pixel-7-and-pro-design-revealed-even-more-fresh-renders_id142800",
                        "image": "https://m-cdn.phonearena.com/images/article/142800-wide-two_1200/Googles-Pixel-7-and-7-Pros-design-gets-revealed-even-more-with-fresh-crisp-renders.jpg",
                        "publishedAt": "2022-09-28T08:14:24Z",
                        "source": {
                            "name": "PhoneArena",
                            "url": "https://www.phonearena.com"
                                }
                        }
                ]
    }





     */

}
