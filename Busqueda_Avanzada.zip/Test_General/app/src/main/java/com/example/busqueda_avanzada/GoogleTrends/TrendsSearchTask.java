package com.example.busqueda_avanzada.GoogleTrends;

import android.os.AsyncTask;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
/*
public class TrendsSearchTask extends AsyncTask<String, Void, Trends> {

    @Override
    protected Trends doInBackground(String... strings) {
        return null;

        try {
            JsonObject resultados = search.getJson();
            return parseGoogleTrendsResult(resultados);
        } catch (SerpApiClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    private Trends parseGoogleTrendsResult(JsonObject resultados) {
        Gson gson = new Gson();
        return gson.fromJson(resultados, Trends.class);
    }

    @Override
    protected void onPostExecute(Trends resultados) {

    }

}
        */