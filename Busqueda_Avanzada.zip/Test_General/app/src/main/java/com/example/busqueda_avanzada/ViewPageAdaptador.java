package com.example.busqueda_avanzada;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class ViewPageAdaptador extends FragmentPagerAdapter {
    public ArrayList<Fragment> listaFragmentos = new ArrayList<Fragment>();

    public ViewPageAdaptador(@NonNull FragmentManager fm, List<Fragment> listaFragmentos) {
        super(fm);
        this.listaFragmentos = (ArrayList<Fragment>) listaFragmentos;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return null;
    }

    @Override
    public int getCount() {
        return listaFragmentos.size();
    }

    //Este método es para actualizar las noticias
    public void setFragmentos(List<Fragment> fragmentos) {
        this.listaFragmentos = (ArrayList<Fragment>) fragmentos;
    }

    public CharSequence getTituloPagina(int position) {
        switch (position) {
            case 0:
                return "Noticias";
            case 1:
                return "NO IMPLEMENTADO";
            case 2:
                return "NO IMPLEMENTADO";
            default:
                return null;
        }
    }
}
