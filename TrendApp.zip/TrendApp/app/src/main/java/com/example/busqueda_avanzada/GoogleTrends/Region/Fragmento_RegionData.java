package com.example.busqueda_avanzada.GoogleTrends.Region;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.example.busqueda_avanzada.GoogleTrends.Trends;

import com.example.busqueda_avanzada.R;

import java.util.ArrayList;
import java.util.List;

public class Fragmento_RegionData extends Fragment {

    private ListView lv_region;
    private RegionAdapter adaptador;


    List<Trends.RegionData.Region> listRegionData;


    public Fragmento_RegionData(Trends.RegionData regionData) {
        Log.d("LOG","Tamaño de lista de regiones: "+regionData.getRegionList().size()) ;
        this.listRegionData = regionData.getRegionList();
    }


    public View onCreateView (LayoutInflater inflador, ViewGroup contenedor, Bundle savedInstance){

        View vista = inflador.inflate(R.layout.fragmento_region, contenedor, false);

        lv_region = vista.findViewById(R.id.lv_regiones);
        adaptador = new RegionAdapter(getActivity(), R.layout.region, listRegionData);
        lv_region.setAdapter(adaptador);

        return vista;

    }

    public void actualizarRegion(Trends.RegionData nuevasRegiones) {
        listRegionData.clear();
        listRegionData = nuevasRegiones.getRegionList();
    }

}