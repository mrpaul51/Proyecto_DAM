package com.example.busqueda_avanzada.Noticias;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.busqueda_avanzada.R;

import java.util.ArrayList;
import java.util.List;

public class Fragmento_Noticias extends Fragment {

    private ListView lv_noticias;
    private NoticiasAdapter adaptador;
    private ArrayList<Noticia> listaNoticias;




    public Fragmento_Noticias(ArrayList<Noticia> listaNoticias) {
        this.listaNoticias = listaNoticias;
    }


    public View onCreateView (LayoutInflater inflador, ViewGroup contenedor, Bundle savedInstance){


        View vista = inflador.inflate(R.layout.fragmento_noticias, contenedor, false);

        lv_noticias = vista.findViewById(R.id.lv_noticias);
        adaptador = new NoticiasAdapter(getActivity(), R.layout.noticia, listaNoticias);
        lv_noticias.setAdapter(adaptador);

        return vista;

    }

    public void actualizarNoticias(ArrayList<Noticia> nuevasNoticias) {
        listaNoticias.clear();
        listaNoticias.addAll(nuevasNoticias);
    }



}
