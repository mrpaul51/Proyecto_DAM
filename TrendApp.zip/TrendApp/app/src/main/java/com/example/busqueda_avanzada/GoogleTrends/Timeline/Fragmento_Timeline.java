package com.example.busqueda_avanzada.GoogleTrends.Timeline;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.anychart.AnyChart;

import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;
import com.anychart.core.cartesian.series.Line;
import com.anychart.data.Mapping;
import com.anychart.data.Set;
import com.anychart.enums.Anchor;
import com.anychart.enums.MarkerType;
import com.anychart.enums.TooltipPositionMode;
import com.anychart.graphics.vector.Stroke;
import com.example.busqueda_avanzada.GoogleTrends.Trends;
import com.example.busqueda_avanzada.R;


import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class Fragmento_Timeline extends Fragment {

    private AnyChartView anyChartView;
    private Trends.TimelineData timelineData;


    public Fragmento_Timeline(Trends.TimelineData timelineData) {
        this.timelineData = timelineData;
    }





    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        View vista = inflater.inflate(R.layout.fragmento_timeline, container, false);
        anyChartView = vista.findViewById(R.id.timeline_chart);

        mostrarChart();



        ArrayList<Integer> valores = timelineData.getValues();
        ArrayList<String> fechas = timelineData.getDates();

        //Estos dos métodos solo muestran una fecha
        /*
        for (Integer i : valores
             ) {

            Log.d("LOG_VALORES", "VALORES: "+ i.toString());
        }
        for (String s : fechas
        ) {

            Log.d("LOG_FECHAS", "FECHAS: "+s);
        }
        */



        return vista;

    }

    private void mostrarChart(){

        Cartesian cart = AnyChart.line();
        cart.animation(true);

        ArrayList<DataEntry> listaData = new ArrayList<>();

       ArrayList<String> listaFechas = timelineData.getDates();



       ArrayList<Integer> listaValores = timelineData.getValues();

       for (int i = 0; i < listaFechas.size(); i++){
           listaData.add(new ValueDataEntry(listaFechas.get(i), listaValores.get(i)));
       }

       Set set = Set.instantiate();
        set.data(listaData);

        Mapping mapeo = set.mapAs("{ x: 'x', value: 'value' }");

        Line series = cart.line(mapeo);
        series.normal().stroke("#004BCD");


        series.name("Interés en el último año");

        cart.xAxis(0).title("Fecha");
        cart.yAxis(0).title("Interés");

        anyChartView.setChart(cart);


    }




}
