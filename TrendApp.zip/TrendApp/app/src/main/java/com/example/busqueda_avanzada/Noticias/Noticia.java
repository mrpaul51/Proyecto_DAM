package com.example.busqueda_avanzada.Noticias;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.gson.JsonObject;

import org.json.JSONObject;

import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Noticia {


    private String titulo;
    private String descripcion;
    private String contenido;
    private URL enlace;
    private URL imagen;
    private Date fechaPublicacion;
    private Fuente fuente;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public URL getEnlace() {
        return enlace;
    }

    public void setEnlace(URL enlace) {
        this.enlace = enlace;
    }

    public URL getImagen() {
        return imagen;
    }

    public void setImagen(URL imagen) {
        this.imagen = imagen;
    }

    public Date getFechaPublicacion() {
        return fechaPublicacion;
    }
    //Sería conveniente hacer un método para obtener la fecha formateada

    public void setFechaPublicacion(Date fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public Fuente getFuente() {
        return fuente;
    }

    public void setFuente(Fuente fuente) {
        this.fuente = fuente;
    }

    public static class Fuente {
        private String nombreFuente;
        private URL enlaceFuente;

        public String getNombreFuente() {
            return nombreFuente;
        }

        public void setNombreFuente(String nombreFuente) {
            this.nombreFuente = nombreFuente;
        }

        public URL getEnlaceFuente() {
            return enlaceFuente;
        }

        public void setEnlaceFuente(URL enlaceFuente) {
            this.enlaceFuente = enlaceFuente;
        }
    }


    public Noticia(JsonObject jsonObject) throws Exception {
        titulo = jsonObject.get("title").getAsString();
        descripcion = jsonObject.get("description").getAsString();
        contenido = jsonObject.get("content").getAsString();
        enlace = new URL(jsonObject.get("url").getAsString());
        imagen = new URL(jsonObject.get("image").getAsString());
        fechaPublicacion = parsearFecha(jsonObject.get("publishedAt").getAsString());
        JsonObject sourceObject = jsonObject.getAsJsonObject("source");
        fuente = new Fuente();
        fuente.setNombreFuente(sourceObject.get("name").getAsString());
        fuente.setEnlaceFuente(new URL(sourceObject.get("url").getAsString()));
    }


    private Date parsearFecha(String fecha) throws ParseException {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.getDefault());
        return formatoFecha.parse(fecha);
    }

    @NonNull
    @Override
    public String toString() {
        return "Noticia:\n" +
                "titulo='" + titulo + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", contenido='" + contenido + '\'' +
                ", enlace=" + enlace +
                ", imagen=" + imagen +
                ", fechaPublicacion=" + fechaPublicacion +
                ", fuente=" + fuente;
    }

    //Ejemplo de noticia extraida de Gnews.
    /*
    {
  "totalArticles": 54904,
  "articles": [
    {
      "title": "Google's Pixel 7 and 7 Pro’s design gets revealed even more with fresh crisp renders",
      "description": "Now we have a complete image of what the next Google flagship phones will look like. All that's left now is to welcome them during their October announcement!",
      "content": "Google’s highly anticipated upcoming Pixel 7 series is just around the corner, scheduled to be announced on October 6, 2022, at 10 am EDT during the Made by Google event. Well, not that there is any lack of images showing the two new Google phones, b... [1419 chars]",
      "url": "https://www.phonearena.com/news/google-pixel-7-and-pro-design-revealed-even-more-fresh-renders_id142800",
      "image": "https://m-cdn.phonearena.com/images/article/142800-wide-two_1200/Googles-Pixel-7-and-7-Pros-design-gets-revealed-even-more-with-fresh-crisp-renders.jpg",
      "publishedAt": "2022-09-28T08:14:24Z",
      "source": {
        "name": "PhoneArena",
        "url": "https://www.phonearena.com"
      }
    }
  ]
}
     */


}
