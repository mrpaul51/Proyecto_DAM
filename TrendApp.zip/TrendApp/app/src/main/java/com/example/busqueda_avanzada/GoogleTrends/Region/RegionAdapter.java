package com.example.busqueda_avanzada.GoogleTrends.Region;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.example.busqueda_avanzada.GoogleTrends.Trends;
import com.example.busqueda_avanzada.R;
import java.util.ArrayList;
import java.util.List;

public class RegionAdapter  extends ArrayAdapter<Trends.RegionData.Region> {


    Activity actividad;
    int idLayout;
    ArrayList<Trends.RegionData.Region> listaRegiones;



    public RegionAdapter(@NonNull Context context, int resource, @NonNull List<Trends.RegionData.Region> objects) {

        super(context, resource, objects);
        actividad = (Activity) context;
        idLayout = resource;
        listaRegiones = (ArrayList<Trends.RegionData.Region>) objects;

    }


    static class Referencias{
        //Aqui van los elementos que componen la region en la interfaz.

        TextView tv_numero, tv_region, tv_valor;
        ProgressBar pb_valor;

    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View layout_Personalizado;
        LayoutInflater inflador;
        Referencias ref;


        if (convertView == null ) {
            inflador = actividad.getLayoutInflater();
            layout_Personalizado = inflador.inflate(idLayout, null);


            TextView tv_num = (TextView) layout_Personalizado.findViewById(R.id.tv_region_orden);
            TextView tv_region =(TextView) layout_Personalizado.findViewById(R.id.tv_region_region);
            TextView tv_valor =(TextView) layout_Personalizado.findViewById(R.id.tv_region_valor);
            ProgressBar pb_valor = layout_Personalizado.findViewById(R.id.pb_region_valor);


            ref = new RegionAdapter.Referencias();

            ref.tv_numero = tv_num;
            ref.tv_region = tv_region;
            ref.tv_valor = tv_valor;
            ref.pb_valor = pb_valor;


            layout_Personalizado.setTag(ref);
        }

        else {
            layout_Personalizado = convertView;
            ref = (RegionAdapter.Referencias) layout_Personalizado.getTag();
        }


        Trends.RegionData.Region region = listaRegiones.get(position);

        Log.d("LOG", "Lista de noticias"+ listaRegiones.size());
        Log.d("LOG", "Noticia"+region.toString());

        ref.tv_numero.setText(String.valueOf(position + 1));
        ref.tv_region.setText(region.getLocation());
        ref.tv_valor.setText(String.valueOf(region.getValue()));
        ref.pb_valor.setProgress(region.getValue());



        return layout_Personalizado;




    }
}

