package com.example.busqueda_avanzada;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.example.busqueda_avanzada.GoogleTrends.Region.Fragmento_RegionData;
import com.example.busqueda_avanzada.GoogleTrends.Timeline.Fragmento_Timeline;
import com.example.busqueda_avanzada.GoogleTrends.Trends;
import com.example.busqueda_avanzada.GoogleTrends.TrendsSearchTask;
import com.example.busqueda_avanzada.Noticias.Fragmento_Noticias;
import com.example.busqueda_avanzada.Noticias.Noticia;
import com.example.busqueda_avanzada.Noticias.NoticiasSearchTask;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;


public class MainActivity extends AppCompatActivity {

    ImageButton imgAvanzado;
    LinearLayout layoutAvanzado;

    private TabLayout tabLayout;
    FrameLayout frameLayout;
    ListView listView;
    EditText editTextBusqueda;

    ImageButton btn_buscar;
    Button btn_cancelar, btn_guardar;
    ImageButton btn_borrar_pref;

    ArrayList<Fragment> listaFragmentos;
    Fragmento_Noticias frag_Noticias;
    Fragmento_RegionData frag_Region;
    Fragmento_Timeline frag_timeLine;

    String idioma = "es";

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        getSupportActionBar().hide();





        listaFragmentos = new ArrayList<>();

        btn_cancelar = findViewById(R.id.btn_cancelar);
        btn_guardar = findViewById(R.id.btn_guardar);

        imgAvanzado = findViewById(R.id.img_avanzado);
        btn_buscar = findViewById(R.id.img_buscar);
        layoutAvanzado = findViewById(R.id.layout_avanzado);

        //TAB LAYOUT
        frameLayout = findViewById(R.id.frameLayout);
        tabLayout = findViewById(R.id.tab_layout);

        tabLayout.addTab(tabLayout.newTab().setText("Noticias"));   //0
        tabLayout.addTab(tabLayout.newTab().setText("Interés por región"));//1
        tabLayout.addTab(tabLayout.newTab().setText("Interés en el tiempo")); //2

        editTextBusqueda = findViewById(R.id.search_text);



        //Se establecen las listas de elementos para los autocomplete textbox
        Set<String> listaPaises = new TreeSet<>();
        Locale esLocale = new Locale("es", "ES");

        for (Locale locale : Locale.getAvailableLocales()) {
            if (!TextUtils.isEmpty(locale.getDisplayCountry())) {
                listaPaises.add(locale.getDisplayCountry(esLocale));
            }
        }

        ArrayList<String> listaCategorias = new ArrayList<>(Arrays.asList(
                "Arte y entretenimiento",
                "Vehículos",
                "Belleza y Fitness",
                "Libros y Literatura",
                "Finanzas",
                "Cómics y dibujos animados",
                "Artesanía y aficiones",
                "Educación",
                "Electrónica y Gadgets",
                "Moda",
                "Comida",
                "Juegos",
                "Salud",
                "Hogar",
                "Jardín",
                "Humor",
                "Internet y telecomunicaciones",
                "Trabajos y carrera",
                "Gobierno y ley",
                "Estilo de vida",
                "Noticias",
                "Comunidades en línea",
                "Animales de compañía",
                "Bienes raíces",
                "Ciencia",
                "Compras",
                "Deportes",
                "Viajar",
                "Religión",
                "Historia",
                "Películas",
                "Clima"
        ));



        //Se crean y añaden los adapatadores al autocomplete
        ArrayAdapter<String> adaptadorPaises = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, listaPaises.toArray(new String[0]));
        AutoCompleteTextView paisAutocomplete = findViewById(R.id.acTV_paises);
        paisAutocomplete.setAdapter(adaptadorPaises);

        ArrayAdapter<String> adaptadorCategorias = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, listaCategorias.toArray(new String[0]));
        AutoCompleteTextView categoriasAutocomplete = findViewById(R.id.acTV_cateogria);
        categoriasAutocomplete.setAdapter(adaptadorCategorias);




        imgAvanzado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (layoutAvanzado.getVisibility() == View.VISIBLE) {
                    layoutAvanzado.setVisibility(View.GONE);
                } else {
                    layoutAvanzado.setVisibility(View.VISIBLE);
                }

            }
        });






        btn_buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                //DECLARACIÓN DE LAS TAREAS DE BÚSQUEDA

                NoticiasSearchTask noticiasSearchTask = new NoticiasSearchTask(new NoticiasSearchTask.NoticiasSearchListener() {
                    @Override
                    public void onNoticiasSearchCompleted(ArrayList<Noticia> listaNoticias) {


                        frag_Noticias = new Fragmento_Noticias(listaNoticias);

                        listaFragmentos.add(frag_Noticias);
                        Log.d("LOG", "ListaNoticias tamaño:"+listaNoticias.size());


                        int selectedTabPosition = tabLayout.getSelectedTabPosition();
                        switch (selectedTabPosition) {
                            case 0:
                                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, frag_Noticias).commit();
                                break;
                            case 1:
                                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, frag_Region).commit();
                                break;
                            case 2:
                                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, frag_timeLine).commit();
                                break;
                        }

                    }
                    @Override
                    public void onNoticiasSearchFailed(Exception e) {//error
                    }
                });

                TrendsSearchTask trendsSearchTask = new TrendsSearchTask(new TrendsSearchTask.TrendsSearchListener() {
                    @Override
                    public void onTrendsSearchCompleted(Trends tendencias) {
                        frag_Region = new Fragmento_RegionData(tendencias.getRegionData());

                        frag_timeLine = new Fragmento_Timeline(tendencias.getTimelineData());

                        /*
                        Log.d("LOG", "FRAG REGION: "+frag_Region.toString());
                         Log.d("LOG", "FRAG TIMELINE: "+frag_timeLine.toString());
                        */

                        listaFragmentos.add(frag_Region);
                        listaFragmentos.add(frag_timeLine);

                        int selectedTabPosition = tabLayout.getSelectedTabPosition();
                        switch (selectedTabPosition) {
                            case 0:
                                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, frag_Noticias).commit();
                                break;
                            case 1:
                                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, frag_Region).commit();
                                break;
                            case 2:
                                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, frag_timeLine).commit();
                                break;
                        }

                    }

                    @Override
                    public void onTrendsSearchFailed(Exception e) {
                        Log.d("LOG", "ERROR: "+e.toString());

                    }
                });


               noticiasSearchTask.execute(editTextBusqueda.getText().toString(), paisAutocomplete.getText().toString(), idioma);
               trendsSearchTask.execute(editTextBusqueda.getText().toString(), paisAutocomplete.getText().toString(), idioma);


            }
        });



        // Listener de TabLayout
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (listaFragmentos.size()!=0) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, listaFragmentos.get(tab.getPosition())).commit();
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });


        btn_cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextBusqueda.setText("");
                categoriasAutocomplete.setText("");
                paisAutocomplete.setText("");


            }
        });


      /// PREFERENCIAS



       listView = findViewById(R.id.lv_preferencias);

        SharedPreferences preferences = getSharedPreferences("Preferencias", Context.MODE_PRIVATE);
        String parametrosGuardados = preferences.getString("parametros", null);

        List<String> parametroList = new ArrayList<>();

        if (parametrosGuardados != null) {
            try {
                JSONArray parametrosArray = new JSONArray(parametrosGuardados);


                for (int i = 0; i < parametrosArray.length(); i++) {
                    JSONObject parametroJson = parametrosArray.getJSONObject(i);
                    String palabraClave = parametroJson.getString("palabraClave");
                    String pais = parametroJson.getString("pais");
                    String categoria = parametroJson.getString("categoria");
                    parametroList.add(palabraClave + ": " + pais + ": " + categoria);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        Preferences_Adapter adapter = new Preferences_Adapter(this,R.layout.preferencia, parametroList);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String parametroSeleccionado = parametroList.get(position);

                String[] parametrosSeparados = parametroSeleccionado.split(":");
                String palabraClave = parametrosSeparados[0].trim();
                String pais = parametrosSeparados[1].trim();
                String categoria = parametrosSeparados[2].trim();

                editTextBusqueda.setText(palabraClave);
                categoriasAutocomplete.setText(categoria);
                paisAutocomplete.setText(pais);

            }
        });


        btn_guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String palabraClave = editTextBusqueda.getText().toString();
                String pais = paisAutocomplete.getText().toString();
                String categoria = categoriasAutocomplete.getText().toString();

                Calendar calendario = Calendar.getInstance();
                SimpleDateFormat formatoFecha = new SimpleDateFormat("EEEE dd 'de' MMMM, yyyy", Locale.getDefault());
                String fechaFormateada = formatoFecha.format(calendario.getTime());

                SharedPreferences preferencias_Busqueda = getSharedPreferences("Preferencias",  Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias_Busqueda.edit();


                String parametrosGuardados = preferencias_Busqueda.getString("parametros", null);
                JSONArray parametrosArray;
                if (parametrosGuardados != null) {
                    try {
                        parametrosArray = new JSONArray(parametrosGuardados);
                    } catch (JSONException e) {
                        parametrosArray = new JSONArray();
                        e.printStackTrace();
                    }
                } else {
                    parametrosArray = new JSONArray();
                }


                JSONObject parametrosJson = new JSONObject();
                try {
                    parametrosJson.put("palabraClave", palabraClave);
                    parametrosJson.put("pais", pais);
                    parametrosJson.put("categoria", categoria);
                    parametrosJson.put("fecha", fechaFormateada);
                } catch (JSONException e) {
                    e.printStackTrace();
                }


                parametrosArray.put(parametrosJson);


                editor.putString("parametros", parametrosArray.toString());
                editor.apply();

                Toast.makeText(MainActivity.this, "Se han guardado los parámetros", Toast.LENGTH_SHORT).show();

                actualizarListView();
            }
        });




        btn_borrar_pref = findViewById(R.id.btn_borrar_preferencias);

        btn_borrar_pref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                SharedPreferences preferencias_Busqueda = getSharedPreferences("Preferencias",  Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias_Busqueda.edit();


                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("Confirmar borrado de preferencias?");
                dialog.setMessage("¿Está seguro de que desea borrar el archivo?");


                dialog.setPositiveButton("Borrar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        editor.clear().commit();
                        actualizarListView();
                    }
                });
                dialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                AlertDialog dialogoCreado = dialog.create();
                dialogoCreado.show();



            }
        });







    }

    private void actualizarListView() {
        SharedPreferences preferences = getSharedPreferences("Preferencias", Context.MODE_PRIVATE);
        String parametrosGuardados = preferences.getString("parametros", null);

        List<String> parametroList = new ArrayList<>();

        if (parametrosGuardados != null) {
            try {
                JSONArray parametrosArray = new JSONArray(parametrosGuardados);

                for (int i = 0; i < parametrosArray.length(); i++) {
                    JSONObject parametroJson = parametrosArray.getJSONObject(i);
                    String palabraClave = parametroJson.getString("palabraClave");
                    String pais = parametroJson.getString("pais");
                    String categoria = parametroJson.getString("categoria");
                    parametroList.add(palabraClave + ": " + pais + ": " + categoria);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        Preferences_Adapter adapter = new Preferences_Adapter(this, R.layout.preferencia, parametroList);
        listView.setAdapter(adapter);
    }




}