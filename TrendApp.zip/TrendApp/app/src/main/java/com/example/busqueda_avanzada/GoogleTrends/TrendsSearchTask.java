package com.example.busqueda_avanzada.GoogleTrends;

import android.os.AsyncTask;
import android.util.Log;

import com.example.busqueda_avanzada.Noticias.Noticia;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class TrendsSearchTask extends AsyncTask<String, Void, Void> {

    private static final String TAG = "Tarea Trends API";
    private TrendsSearchListener listener;

    public TrendsSearchTask(TrendsSearchListener listener) {
        this.listener = listener;
    }

    private static final String TRENDS_API_KEY = "a5feb85c6bdb781ed6072af5a08e78eead07c1c0d07de9144b443fed21cb6661";
    private static final String TRENDS_API_ENDPOINT = "https://serpapi.com/search.json";

    @Override
    protected Void doInBackground(String... parametros) {

        String clave = parametros[0];
        String pais = parametros[1];

        Trends.TimelineData timeLineData = null;
        Trends.RegionData regionData = null;

        try {
            String claveEncoded = URLEncoder.encode(clave, "UTF-8");

            // Interes en el tiempo
            String urlStringTiempo = TRENDS_API_ENDPOINT
                    + "?engine=google_trends"
                    + "&q=" + claveEncoded
                    + "&data_type=TIMESERIES"
                    + "&api_key=" + TRENDS_API_KEY;

            URL urlTiempo = new URL(urlStringTiempo);
            HttpURLConnection connectionTiempo = (HttpURLConnection) urlTiempo.openConnection();
            connectionTiempo.setRequestMethod("GET");

            int responseCodeTiempo = connectionTiempo.getResponseCode();
            if (responseCodeTiempo == HttpURLConnection.HTTP_OK) {
                BufferedReader readerTiempo = new BufferedReader(new InputStreamReader(connectionTiempo.getInputStream()));
                StringBuilder responseTiempo = new StringBuilder();
                String lineTiempo;
                while ((lineTiempo = readerTiempo.readLine()) != null) {
                    responseTiempo.append(lineTiempo);
                }
                readerTiempo.close();

                JsonObject jsonObjectTiempo = JsonParser.parseString(responseTiempo.toString()).getAsJsonObject();
                Log.d("LOG_TIEMPO", "TIMELINE:" +jsonObjectTiempo.toString());
               timeLineData = new  Trends.TimelineData(jsonObjectTiempo);
            }

            // Interes por región
            String urlStringRegion = TRENDS_API_ENDPOINT
                    + "?engine=google_trends"
                    + "&q=" + claveEncoded
                    + "&data_type=GEO_MAP_0"
                    + "&api_key=" + TRENDS_API_KEY;

            URL urlRegion = new URL(urlStringRegion);
            HttpURLConnection connectionRegion = (HttpURLConnection) urlRegion.openConnection();
            connectionRegion.setRequestMethod("GET");

            int responseCodeRegion = connectionRegion.getResponseCode();
            if (responseCodeRegion == HttpURLConnection.HTTP_OK) {
                BufferedReader readerRegion = new BufferedReader(new InputStreamReader(connectionRegion.getInputStream()));
                StringBuilder responseRegion = new StringBuilder();
                String lineRegion;
                while ((lineRegion = readerRegion.readLine()) != null) {
                    responseRegion.append(lineRegion);
                }
                readerRegion.close();

                JsonObject jsonObjectRegion = JsonParser.parseString(responseRegion.toString()).getAsJsonObject();
                Log.d("LOG_REGION", "REGIONDATA:" +jsonObjectRegion.toString());
                regionData = new Trends.RegionData(jsonObjectRegion);
            }

            // Crear objeto Trends con los datos obtenidos
            Trends trends = new Trends(timeLineData, regionData);

            listener.onTrendsSearchCompleted(trends);


        } catch (Exception e) {
            Log.e(TAG, "error", e);
            listener.onTrendsSearchFailed(e);
        }



        return null;
    }




    public interface TrendsSearchListener {
        void onTrendsSearchCompleted(Trends tendencias);
        void onTrendsSearchFailed(Exception e);
    }

}