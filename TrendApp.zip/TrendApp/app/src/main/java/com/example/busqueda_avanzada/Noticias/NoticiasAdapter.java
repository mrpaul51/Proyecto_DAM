package com.example.busqueda_avanzada.Noticias;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.busqueda_avanzada.R;
import com.squareup.picasso.Picasso;

import java.lang.ref.Reference;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class NoticiasAdapter extends ArrayAdapter<Noticia> {

    Activity actividad;
    int idLayout;
    List<Noticia> listaNoticias;

    //Constructor
    public NoticiasAdapter(@NonNull Context context, int resource, @NonNull List<Noticia> noticias) {
        super(context, resource, noticias);

            actividad = (Activity) context;
            idLayout = resource;
            listaNoticias = noticias;
    }

    static class Referencias{
        //Aqui van los elementos que componen la noticia en la interfaz (imageView, textView...)
        ImageView imagenNoticia;
        TextView tituloNoticia, fechaNoticia, webNoticia, contenidoNoticia;


    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View layout_Personalizado;
        LayoutInflater inflador;
        Referencias ref;














        if (convertView == null ) {
            inflador = actividad.getLayoutInflater();
            layout_Personalizado = inflador.inflate(idLayout, null);

            ImageView imv_imagen = (ImageView) layout_Personalizado.findViewById(R.id.imv_imagenNoticia);
            TextView tv_titulo = (TextView) layout_Personalizado.findViewById(R.id.tv_tituloNoticia);
            TextView tv_fecha =(TextView) layout_Personalizado.findViewById(R.id.tv_fechaNoticia);
            TextView tv_web =(TextView) layout_Personalizado.findViewById(R.id.tv_webNoticia);
            TextView tv_contenido = (TextView) layout_Personalizado.findViewById(R.id.tv_contenido);

            ref = new Referencias();

            ref.tituloNoticia = tv_titulo;
            ref.fechaNoticia = tv_fecha;
            ref.imagenNoticia = imv_imagen;
            ref.webNoticia = tv_web;
            ref.contenidoNoticia = tv_contenido;


            layout_Personalizado.setTag(ref);
        }

        else {
            layout_Personalizado = convertView;
            ref = (Referencias) layout_Personalizado.getTag();
        }

        Noticia noticia = listaNoticias.get(position);

        Log.d("LOG", "Lista de noticias"+ listaNoticias.size());
        Log.d("LOG", "Noticia"+noticia.toString());




        SimpleDateFormat formatoFecha = new SimpleDateFormat("EEEE d 'de' MMMM, yyyy", new Locale("es", "ES"));
        String fechaFormateada = formatoFecha.format(noticia.getFechaPublicacion());
        ref.fechaNoticia.setText("Fecha de publicación: " + fechaFormateada);

        ref.webNoticia.setText(noticia.getEnlace().toString());
        Picasso.get().load(noticia.getImagen().toString()).into(ref.imagenNoticia);
        ref.tituloNoticia.setText((noticia.getTitulo()));


        String contenido = noticia.getContenido();
        int longitud_Max = 240;
        String texto_Abreviado = contenido.substring(0, Math.min(contenido.length(), longitud_Max));
        String texto_Completo = texto_Abreviado + "...más en " + noticia.getFuente().getNombreFuente();

        ref.contenidoNoticia.setText(texto_Completo);




        layout_Personalizado.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(actividad);
                builder.setTitle("Opciones de la noticia")
                        .setMessage("¿Deseas ir a la web de la noticia?")
                        .setPositiveButton("Ir a la web", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intencion_web = new Intent(Intent.ACTION_VIEW);
                                intencion_web.setData(Uri.parse(noticia.getEnlace().toString()));
                                actividad.startActivity(intencion_web);
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                AlertDialog dialog = builder.create();
                dialog.show();
                return true;
            }
        });



        return layout_Personalizado;
    }
}
