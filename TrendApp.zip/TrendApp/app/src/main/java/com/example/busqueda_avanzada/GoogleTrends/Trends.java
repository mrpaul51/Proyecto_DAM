package com.example.busqueda_avanzada.GoogleTrends;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;

public class Trends {




    private RegionData regionData;
    private TimelineData timelineData;


    //GETTERS Y SETTERS

    public TimelineData getTimelineData() {
        return timelineData;
    }

    public void setTimelineData(TimelineData timelineData) {
        this.timelineData = timelineData;
    }

    public RegionData getRegionData() {
        return regionData;
    }

    public void setRegionData(RegionData regionData) {
        this.regionData = regionData;
    }



    //CONSTRUCTOR
    public Trends(TimelineData timelineData, RegionData regionData) {
        this.timelineData = timelineData;
        this.regionData = regionData;
    }


    public static class TimelineData {
        private String parameter;
        private ArrayList<String> dates;
        private ArrayList<Integer> values;

        public String getParameter() {
            return parameter;
        }

        public void setParameter(String parameter) {
            this.parameter = parameter;
        }

        public ArrayList<String> getDates() {
            return dates;
        }

        public void setDates(ArrayList<String> dates) {
            this.dates = dates;
        }

        public ArrayList<Integer> getValues() {
            return values;
        }

        public void setValues(ArrayList<Integer> values) {
            this.values = values;
        }

        public TimelineData(JsonObject jsonObject) {
            if (jsonObject.has("interest_over_time")) {
                JsonObject interestOverTimeObject = jsonObject.getAsJsonObject("interest_over_time");

                if (interestOverTimeObject.has("timeline_data")) {
                    JsonArray timelineArray = interestOverTimeObject.getAsJsonArray("timeline_data");
                    // tamaño 52

                    dates = new ArrayList<>();
                    values = new ArrayList<>();

                    for (JsonElement timelineElement : timelineArray) {
                        JsonObject timelineObject = timelineElement.getAsJsonObject();

                        if (timelineObject.has("values")) {
                            JsonArray valuesArray = timelineObject.getAsJsonArray("values");

                            // Log.d("LOG_ARRAY_CONSTRUCTOR", "TAMAÑO ARRAY:" + timelineArray.size());
                            // El array tiene un tamaño de 52

                            for (JsonElement element : valuesArray) {

                                // Este método se ejecuta por cada elemento

                                if (element instanceof JsonObject) {
                                    JsonObject valueObject = (JsonObject) element;
                                    Log.d("LOG_ELEMENT_CONSTRUCTOR", "ELEMENTO:" + valueObject.toString());
                                    if (valueObject.has("query")) {
                                        String query = valueObject.get("query").getAsString();
                                        parameter = query;
                                    }
                                    if (valueObject.has("value")) {
                                        int value = valueObject.get("value").getAsInt();
                                        values.add(value);
                                    }
                                }
                            }

                            if (timelineObject.has("date")) {
                                String date = timelineObject.get("date").getAsString();
                                dates.add(date);
                            }
                        }
                    }
                }
            }
        }



    }




    public static class RegionData {
        private String parameter;
        private ArrayList<Region> regionList;

        public class Region {
            private String geo;
            private String location;
            private int value;

            public Region(String geo, String location, int value) {
                this.geo = geo;
                this.location = location;
                this.value = value;
            }

            public String getGeo() {
                return geo;
            }
            public String getLocation() {
                return location;
            }
            public int getValue() {
                return value;
            }
            @NonNull
            @Override
            public String toString() {
                return "Pais: "+location+" Valor:"+value;
            }
        }


        //CONSTRUCTOR DE REGION DATA
        public RegionData(JsonObject jsonObject) {
            JsonObject searchParameters = jsonObject.getAsJsonObject("search_parameters");
            parameter = searchParameters.get("q").getAsString();

            regionList = new ArrayList<>();

            JsonArray interestByRegion = jsonObject.getAsJsonArray("interest_by_region");

            for (int i = 0; i < interestByRegion.size(); i++) {
                JsonObject regionObject = interestByRegion.get(i).getAsJsonObject();

                String geo = regionObject.get("geo").getAsString();
                String location = regionObject.get("location").getAsString();
                int value;
                try {
                    value = regionObject.get("value").getAsInt();
                } catch (NumberFormatException e) {
                    value = 0;
                }


                Region region = new Region(geo, location, value);
                Log.d("LOG", "REGION:" +region);
                regionList.add(region);
            }
        }

        public String getParameter() {
            return parameter;
        }

        public ArrayList<Region> getRegionList() {
            return regionList;
        }
    }


    //Anotaciones. El parámetro debería pertenecer a Trends, ya que es común a ambas

}

