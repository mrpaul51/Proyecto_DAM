package com.example.busqueda_avanzada;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class Preferences_Adapter extends ArrayAdapter<String> {



    public Preferences_Adapter(@NonNull Context context, int resource, @NonNull List<String> objects) {
        super(context, resource, objects);

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.preferencia, parent, false);
        }

        String data = getItem(position);


        TextView textViewPalabraClave = view.findViewById(R.id.tv_palabraClave_preferencia);

        TextView textViewPais = view.findViewById(R.id.tv_pais_pref);
        TextView textViewCategoria = view.findViewById(R.id.tv_categoria_pref);


        String[] values = data.split(": ");


        textViewPalabraClave.setText(values[0]);

        textViewPais.setText(values[1]);
        textViewCategoria.setText(values[2]);



        return view;
    }
}
